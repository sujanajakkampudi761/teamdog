# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

# Note: Run this from within the root directory

.\build.ps1 -Script "build.cake" -Target "UpdateCgManifest"