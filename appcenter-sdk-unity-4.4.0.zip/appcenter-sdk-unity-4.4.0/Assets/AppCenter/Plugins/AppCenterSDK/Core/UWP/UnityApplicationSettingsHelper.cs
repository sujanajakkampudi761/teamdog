﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

#if UNITY_WSA_10_0
using UnityEngine;

namespace Microsoft.AppCenter.Unity.Internal.Utils
{
    public class UnityApplicationSettingsHelper : MonoBehaviour
    {
    }
}
#endif
