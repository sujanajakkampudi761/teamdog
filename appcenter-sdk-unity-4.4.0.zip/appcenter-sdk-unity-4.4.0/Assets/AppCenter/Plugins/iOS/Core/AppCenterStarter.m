@implementation AppCenterStarter
//This file is a stub! We're going to replace it at build.
@end