// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

#ifndef NS_DATE_HELPER_H
#define NS_DATE_HELPER_H

#import <Foundation/Foundation.h>

extern "C" void* appcenter_unity_ns_date_convert(long interval);

#endif
