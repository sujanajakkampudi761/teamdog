// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

extern "C" const char* app_center_unity_nserror_domain(void* error);
extern "C" long app_center_unity_nserror_code(void* error);
extern "C" const char* app_center_unity_nserror_description(void* error);
